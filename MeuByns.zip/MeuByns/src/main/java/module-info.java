module br.edu.ifsp.sbv.meubyns {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens br.edu.ifsp.sbv.meubyns to javafx.fxml;
    opens br.edu.ifsp.sbv.logica to javafx.fxml;
    opens br.edu.ifsp.sbv.gui to javafx.fxml;
    exports br.edu.ifsp.sbv.meubyns;
}
