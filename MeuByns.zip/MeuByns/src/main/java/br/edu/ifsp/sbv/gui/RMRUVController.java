/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package br.edu.ifsp.sbv.gui;

import br.edu.ifsp.sbv.logica.MUV;
import br.edu.ifsp.sbv.meubyns.App ;
import java.net.URL;
import java.io.IOException ;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author yhas
 */
public class RMRUVController implements Initializable{
    
    @FXML
    private AnchorPane rootPane ;
    
    @FXML
    private Button voltarHome ;

    @FXML
    private Label velocidade ;
    
    @FXML
    private Label espacoFinal1;

    @FXML
    private Label espacoFinal2;

    @FXML
    private Label espacoFinal3;

    @FXML
    private Label espacoInicial1;

    @FXML
    private Label espacoInicial2;

    @FXML
    private Label espacoInicial3;
    
    @FXML
    private Label tempo1;

    @FXML
    private Label tempo2;

    @FXML
    private Label tempo3;
    
    @FXML
    private Label media1 ;
    
    @FXML
    private Label media2 ;
    
    @FXML
    private Label media3 ;
    
    @FXML
    private Label aceleracao;
    
    private MUV mv ;
    
    @FXML
    public void alterarLabelVelocidade(double valor) {
        velocidade.setText("Velocidade = " + valor + "m/s") ;
    }
    
    @FXML
    public void alterarLabelAceleracao(double valor) {
        aceleracao.setText("Aceleração = " + valor + "m/s^2");
    }
    
    @FXML 
    public void alterarLabelTabelas(double [][] valores) {
        espacoInicial1.setText(""+valores[0][0]) ;
        espacoInicial2.setText(""+valores[1][0]) ;
        espacoInicial3.setText(""+valores[2][0]) ;
        espacoFinal1.setText(""+valores[0][1]) ;
        espacoFinal2.setText(""+valores[1][1]) ;
        espacoFinal3.setText(""+valores[2][1]) ;
        tempo1.setText(""+valores[0][2]) ;
        tempo2.setText(""+valores[1][2]) ;
        tempo3.setText(""+valores[2][2]) ;
    }
    
    @FXML
    public void alterarLabelMedias (double [] valores) {
        media1.setText("" + valores[0]) ;
        media2.setText("" + valores[1]) ;
        media3.setText("" + valores[2]) ;
    }
    
    public void Pegar() {
        mv = (MUV) App.enviarObjeto("MRUVController.java");
        this.alterarLabelTabelas(mv.getValores());
        this.alterarLabelMedias(mv.getMedias());
        this.alterarLabelVelocidade(mv.velocidade());
        this.alterarLabelAceleracao(mv.getAceleracao());
    }
    
    @FXML
    public void retorno() throws IOException {
        URL url = App.class.getResource("tMRUV.fxml") ;
        FXMLLoader fxml = new FXMLLoader(url) ;
        Parent raiz = fxml.load();
        
        Stage stage = (Stage) rootPane.getScene().getWindow() ;
        stage.setScene(new Scene(raiz)); 
        stage.setTitle("Primary") ;
        stage.show() ;
        
    }
    
    @FXML
    public void voltarParaHome () throws IOException{
        URL url = App.class.getResource("primary.fxml") ;
        FXMLLoader fxml = new FXMLLoader(url) ;
        Parent raiz = fxml.load();
        
        Stage stage = (Stage) rootPane.getScene().getWindow() ;
        stage.setScene(new Scene(raiz)); 
        stage.setTitle("Primary") ;
        stage.show() ;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.Pegar();
    }

    
}

