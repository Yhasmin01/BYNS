/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsp.sbv.logica;

/**
 *
 * @author nicho
 */
public class Circulo extends Dados{
    private String [] nomes = {"Diâmetro"} ;
    private double [] medias = new double[3] ;
    private double raio ;
    private double volume ;
    private double perimetro ;
    
    public void setRaio () {
        medias = super.getMedia() ;
        raio = medias[0] / 2 ;
    }
    
    public double getRaio () {
        return raio ;
    }
    
    public void setVolume () {
        this.setRaio() ;
        volume = 3.14*raio*raio ;
    }
    
    public void setPerimetro () {
        this.setRaio() ;
        perimetro = 2*3.14*raio ;
    }
    
    public double getVolume () {
        this.setVolume() ;
        return volume ;
    }
    
    public void mostrar () {
        double [][] dados = super.getValores() ;
        this.setVolume();
        this.setPerimetro();
        
        for (int i = 0 ; i < 3 ; i++) {
            System.out.print ((i+1) + " ") ;
            for (int j = 0 ; j < 3 ; j++) {
                 System.out.print (dados[i][j] + " ") ;
            }
            System.out.println() ;
        }
        
        System.out.println("Volume = " + volume) ;
        System.out.println("Perimetro = " + perimetro);
    }
}
