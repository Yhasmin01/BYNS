/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package br.edu.ifsp.sbv.gui;

import br.edu.ifsp.sbv.logica.Circulo;
import br.edu.ifsp.sbv.meubyns.App ;
import java.net.URL;
import java.io.IOException ;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author nicho
 */
public class RCirculoController implements Initializable{
    
    @FXML
    private AnchorPane rootPane ;
    
    @FXML
    private Button BT ;

    @FXML
    private Label volume ;
    
    @FXML
    private Label profundidade1 ;
    
    @FXML
    private Label profundidade2 ;
    
    @FXML
    private Label profundidade3 ;
    
    @FXML
    private Label altura1 ;
    
    @FXML
    private Label altura2 ;
    
    @FXML
    private Label altura3 ;
    
    @FXML
    private Label largura1 ;
    
    @FXML
    private Label largura2 ;
    
    @FXML
    private Label largura3 ;
    
    @FXML
    private Label media1 ;
    
    @FXML
    private Label media2 ;
    
    @FXML
    private Label media3 ;
    
    
    private Circulo retangulo ;
    
    @FXML
    public void alterarLabelVolume(double valor) {
        volume.setText("Volume = " + valor + "m*3") ;
    }
    
    
    @FXML 
    public void alterarLabelTabelas(double [][] valores) {
        largura1.setText(""+valores[0][0]) ;
        largura2.setText(""+valores[0][1]) ;
        largura3.setText(""+valores[0][2]) ;
        altura1.setText(""+valores[1][0]) ;
        altura2.setText(""+valores[1][1]) ;
        altura3.setText(""+valores[1][2]) ;
        profundidade1.setText(""+valores[2][0]) ;
        profundidade2.setText(""+valores[2][1]) ;
        profundidade3.setText(""+valores[2][2]) ;
    }
    
    @FXML
    public void alterarLabelMedias (double [] valores) {
        media1.setText("" + valores[0]) ;
        media2.setText("" + valores[1]) ;
        media3.setText("" + valores[2]) ;
    }
    
    public void Pegar() {
        retangulo = (Circulo) App.enviarObjeto("TCirculoController.java");
        this.alterarLabelVolume(retangulo.getVolume());
        this.alterarLabelTabelas(retangulo.getValores());
        this.alterarLabelMedias(retangulo.getMedia());
    }
    
    @FXML
    public void Retorno() throws IOException {
        URL url = App.class.getResource("tCirculo.fxml") ;
        FXMLLoader fxml = new FXMLLoader(url) ;
        Parent raiz = fxml.load();
        
        Stage stage = (Stage) rootPane.getScene().getWindow() ;
        stage.setScene(new Scene(raiz)); 
        stage.setTitle("Volume Do Circulo") ;
        stage.show() ;
        
    }
    
    @FXML
    public void voltarParaHome () throws IOException{
        URL url = App.class.getResource("primary.fxml") ;
        FXMLLoader fxml = new FXMLLoader(url) ;
        Parent raiz = fxml.load();
        
        Stage stage = (Stage) rootPane.getScene().getWindow() ;
        stage.setScene(new Scene(raiz)); 
        stage.setTitle("Primary") ;
        stage.show() ;
    }


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.Pegar();
    }

    
}