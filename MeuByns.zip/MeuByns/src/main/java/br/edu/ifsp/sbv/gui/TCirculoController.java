/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package br.edu.ifsp.sbv.gui;

import br.edu.ifsp.sbv.logica.Circulo ;
import br.edu.ifsp.sbv.meubyns.App;
import java.net.URL;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author yhasm
 */
public class TCirculoController  {

    @FXML
    private AnchorPane rootPane ;
    
    @FXML
    private Button Calcular ;
    @FXML
    private Button BtVoltar ;
    
    @FXML
    private TextField L1 ;
    @FXML
    private TextField L2 ;
    @FXML
    private TextField L3 ;
    @FXML
    private TextField A1 ;
    @FXML
    private TextField A2 ;
    @FXML
    private TextField A3 ;
    @FXML
    private TextField P1 ;
    @FXML
    private TextField P2 ;
    @FXML
    private TextField P3 ;
    
    public static Circulo c = new Circulo() ;

    @FXML
    public void calcularCirculo() throws IOException {
        
        c.setValores(Double.parseDouble(L1.getText()), 0, 0);
        c.setValores(Double.parseDouble(L2.getText()), 1, 0);
        c.setValores(Double.parseDouble(L3.getText()), 2, 0);
        c.setValores(Double.parseDouble(A1.getText()), 0, 1);
        c.setValores(Double.parseDouble(A2.getText()), 1, 1);
        c.setValores(Double.parseDouble(A3.getText()), 2, 1);
        c.setValores(Double.parseDouble(P1.getText()), 0, 2);
        c.setValores(Double.parseDouble(P2.getText()), 1, 2);
        c.setValores(Double.parseDouble(P3.getText()), 2, 2);
        
        c.mostrar();
        
        this.proximaTela() ;
        
    }
    
     public static Circulo getCirculo() {
        return c ;
    }
    
    private void proximaTela() throws IOException {
        URL url = App.class.getResource("RCirculo.fxml");
        FXMLLoader fxml = new FXMLLoader(url);
        Parent raiz = fxml.load();
        
        // converte a janela da cena atual para stage
        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.setScene(new Scene(raiz));
        stage.setTitle("Home");
        stage.show();
    }
    
    @FXML
    public void Retorno() throws IOException{
        URL url = App.class.getResource("Volumes.fxml") ;
        FXMLLoader fxml = new FXMLLoader(url) ;
        Parent raiz = fxml.load() ;
        
        Stage stage = (Stage) rootPane.getScene().getWindow() ;
        stage.setScene(new Scene(raiz)) ;
        stage.setTitle("Volume") ;
        stage.show();
    }    
    
}
