/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsp.sbv.logica;

/**
 *
 * @author nicho
 */
public class Dados {
    private double [][] valores = new double[3][3];
    private double [] medias = new double [3] ;
    
    public void setMedias () {
        medias[0] = (valores[0][0] + valores[0][1] + valores[0][2]) / valores[0].length ;
        medias[1] = (valores[1][0] + valores[1][1] + valores[1][2]) / valores[1].length ;
        medias[2] = (valores[2][0] + valores[2][1] + valores[2][2]) / valores[2].length ;
    }
    
    public void setValores (double valor, int linha, int coluna) {
        valores[linha][coluna] = valor ;
    }
    
    public double [][] getValores() {
        return valores ;
    }
    public double[] getMedia() {
        this.setMedias();
        return medias ;
    }
}
