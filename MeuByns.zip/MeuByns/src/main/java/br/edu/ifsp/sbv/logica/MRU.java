/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsp.sbv.logica;

/**
 *
 * @author nicho
 */
public class MRU extends Dados{
    private String [] nomes = {"Espaço inicial" ,"Espaço final" ,"Tempo"} ;
    private double [] medias = new double[3] ;
    private double velocidade ;
    private double [][] valores = new double [3][3] ;
    
    @Override
    public void setMedias(){
        valores = super.getValores() ;
        medias[0] = (valores[0][0] + valores[1][0] + valores[2][0]) /3 ;
        medias[1] = (valores[0][1] + valores[1][1] + valores[2][1]) /3 ;
        medias[2] = (valores[0][2] + valores[1][2] + valores[2][2]) /3 ;
    }
    
    public double[] getMedias () {
        return medias;
    }
    
    public void setVelocidade () {
        this.setMedias();
        velocidade = (medias[1] - medias[0]) / medias[2]  ;
    }
    
    public double velocidade () {
        return velocidade ;
    }
    
    public double getVelocidade () {
        return velocidade;
    }
    
    public void mostrar () {
        double [][] valores = super.getValores();
        this.setVelocidade();
        
        for (int i = 0 ; i < valores.length ; i++) {
            System.out.print((i+1) + " ");
            for (int j = 0 ; j < valores[i].length ; j++) {
                System.out.print(valores[i][j] + " ") ;
            }
            System.out.println() ;
        }
        System.out.print("Medias = ") ;
        for (int i = 0 ; i < medias.length ; i++){
            System.out.print(medias[i] + " ") ;
        }
        System.out.println ("\nVelocidade = " + velocidade) ;
    }
}
