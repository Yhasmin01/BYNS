/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package br.edu.ifsp.sbv.gui;

import br.edu.ifsp.sbv.meubyns.App ;
import br.edu.ifsp.sbv.logica.Potencia ;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author nicho
 */
public class RPotenciaController implements Initializable {

    @FXML
    private AnchorPane rootPane ;
    
    @FXML
    private Button voltar ;
    
    @FXML
    private Button voltarHome ;
    
    @FXML
    private Label forca ;
    
    @FXML
    private Label espacoFinal1;

    @FXML
    private Label espacoFinal2;

    @FXML
    private Label espacoFinal3;

    @FXML
    private Label forca1;

    @FXML
    private Label forca2;

    @FXML
    private Label forca3;
    
    @FXML
    private Label tempo1;

    @FXML
    private Label tempo2;

    @FXML
    private Label tempo3;
    
    @FXML
    private Label media1 ;
    
    @FXML
    private Label media2 ;
    
    @FXML
    private Label media3 ;
    
    
    private Potencia potencia ;
    
    @FXML
    public void alterarLabelForca(double valor){
        forca.setText("Força = " + valor + "N") ;
    }
    
    @FXML 
    public void alterarLabelTabelas(double [][] valores) {
        forca1.setText(""+valores[0][0]) ;
        forca2.setText(""+valores[1][0]) ;
        forca3.setText(""+valores[2][0]) ;
        espacoFinal1.setText(""+valores[0][1]) ;
        espacoFinal2.setText(""+valores[1][1]) ;
        espacoFinal3.setText(""+valores[2][2]) ;
        tempo1.setText(""+valores[0][2]) ;
        tempo2.setText(""+valores[1][2]) ;
        tempo3.setText(""+valores[2][1]) ;
    }
    
    @FXML
    public void alterarLabelMedias (double [] valores) {
        media1.setText("" + valores[0]) ;
        media2.setText("" + valores[1]) ;
        media3.setText("" + valores[2]) ;
    }
    
    public void Pegar() {
        potencia = (Potencia) App.enviarObjeto("PotenciaController.java") ;
        this.alterarLabelTabelas(potencia.getValores());
        this.alterarLabelMedias(potencia.getMedias());
        this.alterarLabelForca(potencia.getPotencia());
        
    }
    
    @FXML
    public void retorno() throws IOException {
        URL url = App.class.getResource("tPotencia.fxml") ;
        FXMLLoader fxml = new FXMLLoader(url) ;
        Parent raiz = fxml.load();
        
        Stage stage = (Stage) rootPane.getScene().getWindow() ;
        stage.setScene(new Scene(raiz)); 
        stage.setTitle("Primary") ;
        stage.show() ;
        
    }
    
    @FXML
    public void voltarParaHome () throws IOException{
        URL url = App.class.getResource("primary.fxml") ;
        FXMLLoader fxml = new FXMLLoader(url) ;
        Parent raiz = fxml.load();
        
        Stage stage = (Stage) rootPane.getScene().getWindow() ;
        stage.setScene(new Scene(raiz)); 
        stage.setTitle("Primary") ;
        stage.show() ;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.Pegar();
    }
    
}
