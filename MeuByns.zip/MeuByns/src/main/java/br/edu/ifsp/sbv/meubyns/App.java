package br.edu.ifsp.sbv.meubyns;

import br.edu.ifsp.sbv.gui.TRetanguloController;
import br.edu.ifsp.sbv.gui.TCirculoController;
import br.edu.ifsp.sbv.gui.MRUController;
import br.edu.ifsp.sbv.gui.MRUVController;
import br.edu.ifsp.sbv.gui.PotenciaController;
import br.edu.ifsp.sbv.gui.SegundaLeiController;
import br.edu.ifsp.sbv.gui.TrabalhoController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;

/**
 * JavaFX App
 */
public class App extends Application {

    private static Scene scene;
    
    @Override
    public void start(Stage stage) throws IOException {
        URL url = getClass().getResource("tStart.fxml");
        Parent raiz = FXMLLoader.load(url);
        Scene cena = new Scene(raiz);

        stage.setTitle("Home");
        stage.setScene(cena);
        stage.show() ;
        
    }

    public static void main(String[] args) {
        launch();
    }
    
    public static Object enviarObjeto(String s) {
        switch (s) {
            case "TRetanguloController.java": 
                return TRetanguloController.getRetangulo() ;
            case "TCirculoController.java":
                return TCirculoController.getCirculo();
            case "MRUController.java":
                return MRUController.getMRU();
            case "MRUVController.java":
                return MRUVController.getMUV();
            case "SegundaLeiController.java":
                return SegundaLeiController.getSegundaLei() ;
            case "TrabalhoController.java":
                return TrabalhoController.getTrabalho() ;
            case "PotenciaController.java":
                return PotenciaController.getPotencia();
        }
        return 0 ;
    }

}