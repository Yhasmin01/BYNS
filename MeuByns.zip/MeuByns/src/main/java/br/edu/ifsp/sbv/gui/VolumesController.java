package br.edu.ifsp.sbv.gui;

import br.edu.ifsp.sbv.meubyns.App;
import java.io.IOException;
import java.net.URL;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class VolumesController {

    @FXML
    private AnchorPane rootPane;
    
    @FXML
    private Button secondaryButton;
    private Button Reta ;
    private Button Circulo ;
    
    @FXML
    private void switchToPrimary() throws IOException {
        URL url = App.class.getResource("primary.fxml");
        FXMLLoader fxml = new FXMLLoader(url);
        Parent raiz = fxml.load();
        
        // converte a janela da cena atual para stage
        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.setScene(new Scene(raiz));
        stage.setTitle("Home");
        stage.show();
    }
    
    @FXML
    private void tRetangulo() throws IOException {
        URL url = App.class.getResource("tRetangulo.fxml") ;
        FXMLLoader fxml = new FXMLLoader(url) ;
        Parent raiz = fxml.load();
        
        Stage stage = (Stage) rootPane.getScene().getWindow() ;
        stage.setScene(new Scene(raiz)); 
        stage.setTitle("Volume Do Retangulo") ;
        stage.show() ;
    }
    
    @FXML
    private void tCirculo() throws IOException {
        URL url = App.class.getResource("tCirculo.fxml") ;
        FXMLLoader fxml = new FXMLLoader(url) ;
        Parent raiz = fxml.load();
        
        Stage stage = (Stage) rootPane.getScene().getWindow() ;
        stage.setScene(new Scene(raiz)); 
        stage.setTitle("Volume Do Circulo") ;
        stage.show() ;
    }
}