package br.edu.ifsp.sbv.gui;

import br.edu.ifsp.sbv.meubyns.App;
import java.io.IOException;
import java.net.URL;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class PrimaryController {

    @FXML
    private AnchorPane rootPane ;
    
    @FXML
    private Button primaryButton ;
    
    @FXML
    private Button mruButton;

    @FXML
    private Button mruvButton;

    @FXML
    private Button SegundaLeiButton;

    @FXML
    private Button trabalhoButton;

    @FXML
    private Button potenciaButton;
    
    @FXML
    private void telaVolume() throws IOException {
        URL url = App.class.getResource("Volumes.fxml");
        FXMLLoader fxml = new FXMLLoader(url);
        Parent raiz = fxml.load();
        
        // converte a janela da cena atual para stage
        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.setScene(new Scene(raiz));
        stage.setTitle("Volume");
        stage.show();
    }
  
    @FXML
    private void telaMRU() throws IOException {
        URL url = App.class.getResource("tMRU.fxml");
        FXMLLoader fxml = new FXMLLoader(url);
        Parent raiz = fxml.load();
        
        // converte a janela da cena atual para stage
        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.setScene(new Scene(raiz));
        stage.setTitle("MRU");
        stage.show();
 
    }
    
    @FXML
    private void telaMRUV() throws IOException {
        URL url = App.class.getResource("tMRUV.fxml");
        FXMLLoader fxml = new FXMLLoader(url);
        Parent raiz = fxml.load();
        
        // converte a janela da cena atual para stage
        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.setScene(new Scene(raiz));
        stage.setTitle("MRUV");
        stage.show();
    }
    
    @FXML
    private void telaSegundaLei() throws IOException {
        URL url = App.class.getResource("SegundaLei.fxml");
        FXMLLoader fxml = new FXMLLoader(url);
        Parent raiz = fxml.load();
        
        // converte a janela da cena atual para stage
        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.setScene(new Scene(raiz));
        stage.setTitle("SegundaLei");
        stage.show();
    }
    
    @FXML
    private void telaTrabalho() throws IOException {
        URL url = App.class.getResource("tTrabalho.fxml");
        FXMLLoader fxml = new FXMLLoader(url);
        Parent raiz = fxml.load();
        
        // converte a janela da cena atual para stage
        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.setScene(new Scene(raiz));
        stage.setTitle("Trabalho");
        stage.show();
    }
    
    @FXML
    private void telaPotencia() throws IOException {
        URL url = App.class.getResource("tPotencia.fxml");
        FXMLLoader fxml = new FXMLLoader(url);
        Parent raiz = fxml.load();
        
        // converte a janela da cena atual para stage
        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.setScene(new Scene(raiz));
        stage.setTitle("Potencia");
        stage.show();
    }
    
    
}
