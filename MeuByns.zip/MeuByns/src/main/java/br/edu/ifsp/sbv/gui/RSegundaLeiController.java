/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package br.edu.ifsp.sbv.gui;

import br.edu.ifsp.sbv.logica.SegundaLei;
import br.edu.ifsp.sbv.meubyns.App;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author nicho
 */
public class RSegundaLeiController implements Initializable {

    @FXML
    private AnchorPane rootPane ;
    
    @FXML
    private Button voltar ;
    
    @FXML
    private Button voltarHome ;

    @FXML
    private Label aceleracao ;
    
    @FXML
    private Label forca ;
    
    @FXML
    private Label espacoFinal1;

    @FXML
    private Label espacoFinal2;

    @FXML
    private Label espacoFinal3;

    @FXML
    private Label espacoInicial1;

    @FXML
    private Label espacoInicial2;

    @FXML
    private Label espacoInicial3;
    
    @FXML
    private Label tempo1;

    @FXML
    private Label tempo2;

    @FXML
    private Label tempo3;
    
    @FXML
    private Label media1 ;
    
    @FXML
    private Label media2 ;
    
    @FXML
    private Label media3 ;
    
    
    private SegundaLei segund ;
    
    @FXML
    public void alterarLabelVelocidade(double valor) {
        aceleracao.setText("Aceleração = " + valor + "m/s") ;
    }
    
    public void alterarLabelForca(double valor){
        forca.setText("Força = " + valor + "N") ;
    }
    
    @FXML 
    public void alterarLabelTabelas(double [][] valores) {
        espacoInicial1.setText(""+valores[0][0]) ;
        espacoInicial2.setText(""+valores[1][0]) ;
        espacoInicial3.setText(""+valores[2][0]) ;
        espacoFinal1.setText(""+valores[0][1]) ;
        espacoFinal2.setText(""+valores[1][1]) ;
        espacoFinal3.setText(""+valores[2][1]) ;
        tempo1.setText(""+valores[0][2]) ;
        tempo2.setText(""+valores[1][2]) ;
        tempo3.setText(""+valores[2][2]) ;
    }
    
    @FXML
    public void alterarLabelMedias (double [] valores) {
        media1.setText("" + valores[0]) ;
        media2.setText("" + valores[1]) ;
        media3.setText("" + valores[2]) ;
    }
    
    public void Pegar() {
        segund = (SegundaLei) App.enviarObjeto("SegundaLeiController.java");
        this.alterarLabelTabelas(segund.getValores());
        this.alterarLabelMedias(segund.getMedias());
        this.alterarLabelVelocidade(segund.getAceleracao());
        this.alterarLabelForca(segund.getForca());
    }
    
    @FXML
    public void retorno() throws IOException {
        URL url = App.class.getResource("SegundaLei.fxml") ;
        FXMLLoader fxml = new FXMLLoader(url) ;
        Parent raiz = fxml.load();
        
        Stage stage = (Stage) rootPane.getScene().getWindow() ;
        stage.setScene(new Scene(raiz)); 
        stage.setTitle("Primary") ;
        stage.show() ;
        
    }
    
    @FXML
    public void voltarParaHome () throws IOException{
        URL url = App.class.getResource("primary.fxml") ;
        FXMLLoader fxml = new FXMLLoader(url) ;
        Parent raiz = fxml.load();
        
        Stage stage = (Stage) rootPane.getScene().getWindow() ;
        stage.setScene(new Scene(raiz)); 
        stage.setTitle("Primary") ;
        stage.show() ;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.Pegar();
    }
}
