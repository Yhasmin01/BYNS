/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsp.sbv.logica;

/**
 *
 * @author nicho
 */
public class MUV extends Dados{
    private String [] nomes = {"Espaço inicial", "Espaço final" ,"Tempo"} ;
    private double [] medias = new double[3] ;
    private double velocidade ;
    private double aceleracao ;
    double [][] dados = new double[3][3] ;
    
    
    @Override
    public void setMedias() {
        dados = super.getValores() ;
        medias[0] = (dados[0][0] + dados[1][0] + dados[2][0]) /3;
        medias[1] = (dados[0][1] + dados[1][1] + dados[2][1]) /3;
        medias[2] = (dados[0][2] + dados[1][2] + dados[2][2]) /3;
    }
    
    
    public double[] getMedias () {
        return medias;
    }
    
    public void setVelocidade () {
        this.setMedias();
        velocidade = (medias[1]-medias[0]) / medias[2] ;
    }
    
    public double velocidade () {
        return velocidade ;
    }
    
    public double getAceleracao() {
        return aceleracao ;
    }
    
    public double [] getposicoes () {
        double [] valores = new double [5];
        for (int i = 0 ; i < 5 ; i++) {
            valores[i] = medias[1] + velocidade*i + aceleracao * i * i / 2;
        }
        return valores ;
    }
    
    public void setAceleracao() {
        this.setVelocidade();
        aceleracao = velocidade / medias[2] ;
    }
    
    public void mostrar() {
        this.setAceleracao();
        double [][] valores = super.getValores() ;
        for (int i = 0 ; i < 3 ; i++) {
            System.out.print((i+1) + " ");
            for (int j = 0 ; j < 3 ; j++){
                System.out.print(valores[i][j] + " ") ;
            }
            System.out.println (" Medias: " + medias[i]) ;
        }
        System.out.println(" Velocidade: " + velocidade) ;
        System.out.println(" Aceleração: " + aceleracao) ;
    }
}
