/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsp.sbv.gui;

import br.edu.ifsp.sbv.meubyns.App;
import java.io.IOException;
import java.net.URL;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


/**
 *
 * @author Suzana
 */
public class TStartController {
    
    @FXML
    private AnchorPane rootPane ;
    
    @FXML
    private Button botaoStart ;
    
    @FXML
    private void telaPrimary() throws IOException {
        URL url = App.class.getResource("Primary.fxml");
        FXMLLoader fxml = new FXMLLoader(url);
        Parent raiz = fxml.load();
        
        // converte a janela da cena atual para stage
        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.setScene(new Scene(raiz));
        stage.setTitle("Primary");
        stage.show();
    }
    
}
