/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsp.sbv.logica;

/**
 *
 * @author b3thy
 */
public class Trabalho extends Dados{
    private String [] nome = {"Forca", "Espaco final", "Espaco inicial"};
    private double [] medias = new double[3];
    private double trabalho;
    
    public void setTrabalho(){
        medias = super.getMedia();
        trabalho = medias[0] * (medias[1] - medias[2]);
    }
    
    public double [] getMedias() {
        return medias;
    }
    
    public double getTrabalho() {
        return trabalho ;
    }
    
    public void mostrar(){
        this.setTrabalho();
        System.out.println("O trabalho e de: "+ trabalho);
    }
}
