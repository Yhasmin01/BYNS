/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsp.sbv.logica;

/**
 *
 * @author nicho
 */
public class Retangulo extends Dados {
    private String [] nomes = {"Largura" ,"Altura" ,"Profundidade"} ;
    private double volume ;
    private double [] areas = new double[3] ;
    
    public void setAreas(){
        double [] medias  = super.getMedia() ;
        
        areas[0] = medias[0] * medias[1] ;
        areas[1] = medias[1] * medias[2] ;
        areas[2] = medias[2] * medias[0] ;
        
        
    }
    
    public void setVolume () {
        this.setAreas();
        double [] medias = super.getMedia() ;
        volume = areas[0] * medias[2] ;
        
    }
    
    public double [] getAreas () {
        return areas ;
    }
    public double getVolume () {
        return volume ;
    }
    public void mostrar () {
        double [][] dados = super.getValores() ;
        double [] media = super.getMedia() ;
        this.setVolume() ;
        for (int i = 0 ; i < 3 ; i++) {
            System.out.print(i+1 + " ");
            for (int j = 0 ; j < 3 ; j++) {
                System.out.print(dados[i][j]+ "  ") ;
            }
            System.out.println("media = " + media[i]) ;
            
        }
        System.out.println(nomes[0] + " = " + areas[0] + " " + nomes[1] + " = " + areas[1] + " " + nomes[2] + " = " + areas[2]) ;
        System.out.print("Volume = " + volume + "\n") ;
    }
}
