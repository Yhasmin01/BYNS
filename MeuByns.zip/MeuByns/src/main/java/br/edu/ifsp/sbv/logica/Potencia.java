/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsp.sbv.logica;

/**
 *
 * @author b3thy
 */
public class Potencia extends Dados{
    private String [] nome = {"força", "variação do espaço", "tempo"};
    private double [] medias = new double[3];
    private double potencia ;
    
    public void setMedia() {
        double [][] valores = super.getValores();
        medias[0] = (valores[0][0] + valores[1][0] + valores[2][0]) / valores[0].length;
        medias[1] = (valores[0][1] + valores[1][1] + valores[2][1]) / valores[1].length;
        medias[2] = (valores[0][2] + valores[1][2] + valores[2][2]) / valores[2].length;
    }
    
    public void setPotencia(){
        this.setMedia();
        double trabalho = medias[0] * medias[1] ;
        potencia = trabalho / medias[2] ;
    }
    
    public double [] getMedias() {
        return medias ;
    }
    
    public double getPotencia() {
        return potencia ;
    }
    
    public void mostrar(){
        this.setPotencia();
        
         double [][] dados = super.getValores() ;
          for (int i = 0 ; i < 3 ; i++) {
            System.out.print(i+1 + " ");
            for (int j = 0 ; j < 3 ; j++) {
                System.out.print(dados[i][j]+ "  ") ;
            }
            System.out.println();
          }
         
        System.out.println("O resultado da potencia e de: " + medias[2]);
    }
}
