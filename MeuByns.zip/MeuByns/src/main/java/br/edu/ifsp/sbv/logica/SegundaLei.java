/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsp.sbv.logica;

/**
 *
 * @author nicho
 */
public class SegundaLei extends Dados {
    private String [] nomes = {"massa", "Distancia", "Tempo"} ;
    private double [] medias = new double [3];
    private double aceleracao ;
    private double forca ;
    
    public void setMedia() {
        double [][]valores = super.getValores() ;
        medias[0] = (valores[0][0] + valores[1][0] + valores[2][0]) / valores[0].length;
        medias[1] = (valores[0][1] + valores[1][1] + valores[2][1]) / valores[1].length;
        medias[2] = (valores[0][2] + valores[1][2] + valores[2][2]) / valores[2].length;
    }
    
    public void setForca () {
        this.setMedia() ;
        aceleracao = medias[1]/medias[2] ;
        aceleracao /= medias[2] ;
        forca = medias[0] * aceleracao;
    }
    
    public double getForca () {
        this.setForca() ;
        return forca ;
    }
    public double getAceleracao() {
        return aceleracao ;
    }
    
    public double[] getMedias () {
        return medias ;
    }
    
    public void mostrar() {
        double [][] valores = super.getValores() ;
        this.setForca();
        
        for (int i = 0 ; i < valores.length; i++) {
            System.out.print((i+1) + " ");
            for (int j = 0 ; j < valores[i].length ; j++) {
                System.out.print(valores[i][j] + " ") ;
            }
            System.out.println() ;
        }
        
        System.out.print("Medias = ") ;
        for (double m : medias) {
            System.out.print(m + " ") ;
        }
        System.out.println("\nForça utiliziada = " + forca) ;
    }
}
